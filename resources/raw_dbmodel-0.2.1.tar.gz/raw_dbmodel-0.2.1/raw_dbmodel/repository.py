from raw_dbmodel._compat import RepositoryBase
from raw_dbmodel._types import _T


class Repository(RepositoryBase[_T]):
    pass
